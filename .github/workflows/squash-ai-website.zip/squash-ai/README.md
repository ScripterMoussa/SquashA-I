# Let — AI squash coaching site

A small full-stack starter: a static frontend with a chat coach, backed by an
Express server that proxies chat messages to Claude (Anthropic API).

## What's inside

```
squash-ai/
├── server.js          Express server + /api/chat endpoint
├── package.json
├── .env.example        Copy to .env and add your API key
└── public/
    ├── index.html       Landing page + chat UI
    ├── style.css
    └── script.js        Chat front-end logic
```

## Run it locally

1. Install dependencies:
   ```
   npm install
   ```
2. Copy the env template and add your Anthropic API key:
   ```
   cp .env.example .env
   ```
   Then open `.env` and set `ANTHROPIC_API_KEY=sk-ant-...`
   (Get a key at https://console.anthropic.com if you don't have one.)
3. Start the server:
   ```
   npm start
   ```
4. Open http://localhost:3000

## Why a server at all?

The Anthropic API key must never be exposed in browser code — anyone could
read it from your site's JavaScript and rack up charges on your account.
`server.js` keeps the key server-side and only exposes a narrow `/api/chat`
endpoint that the frontend calls.

## Where to go from here

- **Swap the coaching persona**: edit `COACH_SYSTEM_PROMPT` in `server.js`.
- **Add more pages**: e.g. a drill library, a booking page, player profiles.
- **Persist chat history**: currently it's in-memory in the browser tab only
  — add a database if you want conversations to survive a refresh.
- **Deploy**: this runs on any Node host (Render, Railway, Fly.io, a VPS).
  Set `ANTHROPIC_API_KEY` as an environment variable on whatever platform
  you use — don't commit your `.env` file.
