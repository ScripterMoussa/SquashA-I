const chatLog = document.getElementById('chat-log');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');

const history = [];

function addMessage(role, text) {
  const wrapper = document.createElement('div');
  wrapper.className = role === 'user' ? 'msg msg-player' : 'msg msg-coach';
  const p = document.createElement('p');
  p.textContent = text;
  wrapper.appendChild(p);
  chatLog.appendChild(wrapper);
  chatLog.scrollTop = chatLog.scrollHeight;
}

chatForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;

  addMessage('user', text);
  history.push({ role: 'user', content: text });
  chatInput.value = '';
  chatInput.disabled = true;

  addMessage('assistant', 'Thinking…');
  const thinkingBubble = chatLog.lastElementChild;

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: history })
    });

    const data = await res.json();

    if (!res.ok) {
      thinkingBubble.querySelector('p').textContent = data.error || 'Something went wrong.';
      return;
    }

    thinkingBubble.querySelector('p').textContent = data.reply;
    history.push({ role: 'assistant', content: data.reply });
  } catch (err) {
    thinkingBubble.querySelector('p').textContent = 'Could not reach the coach. Check that the server is running.';
  } finally {
    chatInput.disabled = false;
    chatInput.focus();
  }
});
