require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const COACH_SYSTEM_PROMPT = `You are the AI coach for Let, a squash coaching website.
You give squash players clear, encouraging, technically accurate advice: shot
technique, footwork, drills, match tactics, fitness for squash, and rules.
Keep answers concrete and actionable. When useful, suggest a short drill with
sets/reps or duration. Keep replies focused — a few short paragraphs or a
short list, not an essay, unless the player asks for depth. If a question is
unrelated to squash or squash fitness, politely redirect to squash topics.`;

app.post('/api/chat', async (req, res) => {
  try {
    const { messages } = req.body;

    if (!process.env.ANTHROPIC_API_KEY) {
      return res.status(500).json({
        error: 'Server is missing ANTHROPIC_API_KEY. Copy .env.example to .env and add your key.'
      });
    }

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages array is required' });
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 700,
        system: COACH_SYSTEM_PROMPT,
        messages
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic API error:', errText);
      return res.status(502).json({ error: 'Coach is unavailable right now. Try again shortly.' });
    }

    const data = await response.json();
    const reply = data.content
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('\n');

    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong talking to the coach.' });
  }
});

app.listen(PORT, () => {
  console.log(`Let is running at http://localhost:${PORT}`);
});
